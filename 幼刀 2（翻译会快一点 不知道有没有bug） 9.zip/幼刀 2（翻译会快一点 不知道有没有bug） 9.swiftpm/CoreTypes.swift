// MARK: - 1. CoreTypes (专业后台静默翻译管道 · 零 Warning 纯净版)
import SwiftUI
import UIKit
import CoreGraphics

// MARK: - 颜色 Hex 转换引擎
extension Color {
    init(hex: String) {
        let cleanHex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: cleanHex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch cleanHex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 229, 229, 234)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255.0,
            green: Double(g) / 255.0,
            blue: Double(b) / 255.0,
            opacity: Double(a) / 255.0
        )
    }
    
    func toHex() -> String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        let uiColor = UIColor(self)
        if uiColor.getRed(&r, green: &g, blue: &b, alpha: &a) {
            let redInt = Int(max(0, min(255, lroundf(Float(r * 255.0)))))
            let greenInt = Int(max(0, min(255, lroundf(Float(g * 255.0)))))
            let blueInt = Int(max(0, min(255, lroundf(Float(b * 255.0)))))
            return String(format: "#%02X%02X%02X", redInt, greenInt, blueInt)
        }
        return "#000000"
    }
}

// MARK: - 字体粗细转换引擎
extension Font.Weight {
    static func from(name: String) -> Font.Weight {
        switch name {
        case "light": return .light
        case "regular": return .regular
        case "medium": return .medium
        case "semibold": return .semibold
        case "bold": return .bold
        case "heavy": return .heavy
        default: return .regular
        }
    }
}

// MARK: - 壁纸智能分析
extension UIImage {
    func analyzeWallpaperTone() -> (isLight: Bool, textColor: Color) {
        let size = CGSize(width: 8, height: 8)
        let renderer = UIGraphicsImageRenderer(size: size)
        let sampledImage = renderer.image { _ in self.draw(in: CGRect(origin: .zero, size: size)) }
        guard let cgImage = sampledImage.cgImage,
              let dataProvider = cgImage.dataProvider,
              let pixelData = dataProvider.data,
              let ptr = CFDataGetBytePtr(pixelData) else { return (false, .white) }
        let bytesPerPixel = cgImage.bitsPerPixel / 8
        let bytesPerRow = cgImage.bytesPerRow
        guard bytesPerPixel >= 3 else { return (false, .white) }
        var totalLuminance: CGFloat = 0, totalR: CGFloat = 0, totalG: CGFloat = 0, totalB: CGFloat = 0, count: CGFloat = 0
        for y in 0..<cgImage.height {
            for x in 0..<cgImage.width {
                let offset = y * bytesPerRow + x * bytesPerPixel
                let r = CGFloat(ptr[offset]) / 255.0
                let g = CGFloat(ptr[offset + 1]) / 255.0
                let b = CGFloat(ptr[offset + 2]) / 255.0
                totalLuminance += 0.299 * r + 0.587 * g + 0.114 * b
                totalR += r; totalG += g; totalB += b
                count += 1
            }
        }
        guard count > 0 else { return (false, .white) }
        let avgLum = totalLuminance / count
        let avgR = totalR / count, avgG = totalG / count, avgB = totalB / count
        if avgLum > 0.56 {
            let darkR = max(0.08, min(0.22, avgR * 0.25))
            let darkG = max(0.08, min(0.22, avgG * 0.25))
            let darkB = max(0.09, min(0.25, avgB * 0.28))
            return (true, Color(.sRGB, red: darkR, green: darkG, blue: darkB, opacity: 1.0))
        } else {
            return (false, .white)
        }
    }
}

// MARK: - 语言枚举
enum AppLanguage: String, CaseIterable, Identifiable, Codable {
    case simplifiedChinese = "zh-Hans"
    case traditionalChinese = "zh-Hant"
    case english = "en"
    case japanese = "ja"
    case korean = "ko"
    
    var id: String { self.rawValue }
    
    var displayName: String {
        switch self {
        case .simplifiedChinese: return "简体中文"
        case .traditionalChinese: return "繁體中文"
        case .english: return "English"
        case .japanese: return "日本語"
        case .korean: return "한국어"
        }
    }
    
    var localeIdentifier: String {
        switch self {
        case .simplifiedChinese: return "zh_CN"
        case .traditionalChinese: return "zh_TW"
        case .english: return "en_US"
        case .japanese: return "ja_JP"
        case .korean: return "ko_KR"
        }
    }
    
    var apiTargetCode: String {
        switch self {
        case .simplifiedChinese: return "zh-CN"
        case .traditionalChinese: return "zh-TW"
        case .english: return "en"
        case .japanese: return "ja"
        case .korean: return "ko"
        }
    }
}

// MARK: - 核心多语言系统管理器
class LanguageManager: ObservableObject {
    static let shared = LanguageManager()
    private let languageKey = "App_Selected_Language_Code"
    
    @Published var currentLanguage: AppLanguage = .simplifiedChinese {
        didSet {
            UserDefaults.standard.set(currentLanguage.rawValue, forKey: languageKey)
            AutoTranslationManager.shared.objectWillChange.send()
        }
    }
    
    init() {
        if let savedCode = UserDefaults.standard.string(forKey: languageKey),
           let lang = AppLanguage(rawValue: savedCode) {
            self.currentLanguage = lang
        } else {
            self.currentLanguage = .simplifiedChinese
        }
    }
    
    let dict: [String: [AppLanguage: String]] = [
        // 核心应用支持直接输入汉字直通（彻底解决“微信”、“设置”等专有名词不翻译的问题）
        "app_settings": [.simplifiedChinese: "设置", .traditionalChinese: "設定", .english: "Settings", .japanese: "設定", .korean: "설정"],
        "设置": [.simplifiedChinese: "设置", .traditionalChinese: "設定", .english: "Settings", .japanese: "設定", .korean: "설정"],
        "Settings": [.simplifiedChinese: "设置", .traditionalChinese: "設定", .english: "Settings", .japanese: "設定", .korean: "설정"],
        
        "app_wechat": [.simplifiedChinese: "微信", .traditionalChinese: "微信", .english: "WeChat", .japanese: "メッセージ", .korean: "메시지"],
        "微信": [.simplifiedChinese: "微信", .traditionalChinese: "微信", .english: "WeChat", .japanese: "メッセージ", .korean: "메시지"],
        "WeChat": [.simplifiedChinese: "微信", .traditionalChinese: "微信", .english: "WeChat", .japanese: "メッセージ", .korean: "메시지"],
        
        "app_iscreen": [.simplifiedChinese: "iScreen", .traditionalChinese: "iScreen", .english: "iScreen", .japanese: "iScreen", .korean: "iScreen"],
        "iScreen": [.simplifiedChinese: "iScreen", .traditionalChinese: "iScreen", .english: "iScreen", .japanese: "iScreen", .korean: "iScreen"],
        
        "carrier_name": [.simplifiedChinese: "中国联通", .traditionalChinese: "中華電信", .english: "Carrier", .japanese: "docomo", .korean: "SKT"],
        "edit": [.simplifiedChinese: "编辑", .traditionalChinese: "編輯", .english: "Edit", .japanese: "編集", .korean: "편집"],
        "done": [.simplifiedChinese: "完成", .traditionalChinese: "完成", .english: "Done", .japanese: "完了", .korean: "완료"],
        "search": [.simplifiedChinese: "搜索", .traditionalChinese: "搜尋", .english: "Search", .japanese: "検索", .korean: "검색"],
        "add_widget_nav_title": [.simplifiedChinese: "添加小组件", .traditionalChinese: "加入小工具", .english: "Add Widget", .japanese: "ウィジェットを追加", .korean: "위젯 추가"],
        "close": [.simplifiedChinese: "关闭", .traditionalChinese: "關閉", .english: "Close", .japanese: "閉じる", .korean: "닫기"],
        "cat_all": [.simplifiedChinese: "全部", .traditionalChinese: "全部", .english: "All", .japanese: "すべて", .korean: "전체"],
        "widget_ins_title": [.simplifiedChinese: "ins发布页", .traditionalChinese: "ins發布頁", .english: "Instagram Post", .japanese: "投稿カード", .korean: "인스타 게시물"],
        "sub_ins": [.simplifiedChinese: "Ins 风格图文展示小组件", .traditionalChinese: "Ins 風格圖文展示小工具", .english: "Instagram style post widget", .japanese: "Ins風の写真カード", .korean: "인스타 스타일 게시물 위젯"],
        "widget_korean_title": [.simplifiedChinese: "寄语卡片", .traditionalChinese: "寄語卡片", .english: "Quote Card", .japanese: "メッセージカード", .korean: "메시지 카드"],
        "sub_korean": [.simplifiedChinese: "韩系简约每日寄语卡片", .traditionalChinese: "韓系簡約每日寄語卡片", .english: "Korean minimal daily quote card", .japanese: "シンプルな韓国風カード", .korean: "심플한 데일리 메시지 카드"],
        "widget_bubble_title": [.simplifiedChinese: "对话框", .traditionalChinese: "對話框", .english: "Chat Bubble", .japanese: "チャットバブル", .korean: "대화 상자"],
        "sub_bubble": [.simplifiedChinese: "聊天气泡风格小组件", .traditionalChinese: "聊天氣泡風格小工具", .english: "Chat bubble widget", .japanese: "吹き出しウィジェット", .korean: "채팅 말풍선 위젯"],
        "widget_photo_title": [.simplifiedChinese: "卡片", .traditionalChinese: "卡片", .english: "Photo Card", .japanese: "フォトカード", .korean: "사진 카드"],
        "sub_photo": [.simplifiedChinese: "桌面精选照片展示卡片", .traditionalChinese: "桌面精選照片展示卡片", .english: "Featured photo display card", .japanese: "お気に入り写真カード", .korean: "홈 화면 사진 카드"],
        "badge_4x4": [.simplifiedChinese: "4×4 大号", .traditionalChinese: "4×4 大號", .english: "4×4 Large", .japanese: "4×4 大", .korean: "4×4 대형"],
        "badge_4x2": [.simplifiedChinese: "4×2 中号", .traditionalChinese: "4×2 中號", .english: "4×2 Medium", .japanese: "4×2 中", .korean: "4×2 중형"],
        "badge_2x2": [.simplifiedChinese: "2×2 小号", .traditionalChinese: "2×2 小號", .english: "2×2 Small", .japanese: "2×2 Small", .korean: "2×2 소형"],
        "already_added": [.simplifiedChinese: "已在主屏幕", .traditionalChinese: "已在主畫面", .english: "Added to Home Screen", .japanese: "追加済み", .korean: "추가됨"],
        "add_to_home": [.simplifiedChinese: "添加小组件到主屏幕", .traditionalChinese: "加入小工具到主畫面", .english: "Add Widget to Home Screen", .japanese: "ホーム画面に追加", .korean: "홈 화면에 위젯 추가"],
        "settings_title": [.simplifiedChinese: "设置", .traditionalChinese: "設定", .english: "Settings", .japanese: "設定", .korean: "설정"],
        "device_name": [.simplifiedChinese: "极客手机", .traditionalChinese: "極客手機", .english: "Geek Phone", .japanese: "マイ端末", .korean: "마이 폰"],
        "apple_id_sub": [.simplifiedChinese: "Apple ID、iCloud、媒体与购买项目", .traditionalChinese: "Apple ID、iCloud、媒體與購買項目", .english: "Apple ID, iCloud, Media & Purchases", .japanese: "Apple ID、iCloud、メディアと購入", .korean: "Apple ID, iCloud, 미디어 및 구입 항목"],
        "language_title": [.simplifiedChinese: "语言", .traditionalChinese: "語言", .english: "Language", .japanese: "言語", .korean: "언어"],
        "display_and_brightness": [.simplifiedChinese: "显示与亮度", .traditionalChinese: "螢幕顯示與亮度", .english: "Display & Brightness", .japanese: "画面表示と明るさ", .korean: "디스플레이 및 밝기"],
        "wallpaper": [.simplifiedChinese: "壁纸", .traditionalChinese: "背景圖片", .english: "Wallpaper", .japanese: "壁紙", .korean: "배경화面"],
        "api_config": [.simplifiedChinese: "API 反代配置", .traditionalChinese: "API 反向代理配置", .english: "API Reverse Proxy", .japanese: "APIプロキシ設定", .korean: "API 프록시 설정"],
        "model_selection": [.simplifiedChinese: "大模型选择", .traditionalChinese: "大模型選擇", .english: "AI Model Selection", .japanese: "AIモデル選択", .korean: "AI 모델 선택"],
        "appearance": [.simplifiedChinese: "外观", .traditionalChinese: "外觀", .english: "Appearance", .japanese: "外観モード", .korean: "화면 모드"],
        "appearance_auto_footer": [.simplifiedChinese: "开启自动后，将跟随您设备的日夜间模式自动切换系统颜色。", .traditionalChinese: "開啟自動後，將跟隨您設備的日夜間模式自動切換系统颜色。", .english: "When automatic is enabled, appearance matches device dark/light mode.", .japanese: "自動をオンにすると、デバイスの外観設定に合わせて切り替わります。", .korean: "자동을 켜면 기기의 다크/라이트 모드에 맞춰 테마가 전환됩니다."],
        "auto": [.simplifiedChinese: "自动", .traditionalChinese: "自動", .english: "Automatic", .japanese: "自動", .korean: "자동"],
        "appearance_selection": [.simplifiedChinese: "外观选择", .traditionalChinese: "外觀選擇", .english: "Appearance Style", .japanese: "外観の選択", .korean: "화면 스타일"],
        "light": [.simplifiedChinese: "浅色", .traditionalChinese: "淺色", .english: "Light", .japanese: "ライト", .korean: "라이트"],
        "dark": [.simplifiedChinese: "深色", .traditionalChinese: "深色", .english: "Dark", .japanese: "ダーク", .korean: "다크"],
        "font_weight_section": [.simplifiedChinese: "系统字体粗细", .traditionalChinese: "系統字體粗細", .english: "System Font Weight", .japanese: "フォントの太さ", .korean: "서체 굵기"],
        "widget_font_priority": [.simplifiedChinese: "组件字体优先级", .traditionalChinese: "小工具字體優先級", .english: "Widget Font Priority", .japanese: "ウィジェットフォント優先", .korean: "위젯 서체 우선순위"],
        "widget_font_priority_footer": [.simplifiedChinese: "开启后，组件内自定义设置的字体样式优先显示，不被系统字体粗细覆盖；关闭后，所有组件统一遵从系统字体设置。", .traditionalChinese: "開啟後，小工具內自訂設定的字體樣式優先顯示，不被系統字體粗細覆蓋；關閉後，所有小工具統一遵從系統字體設定。", .english: "When enabled, custom widget font styles take priority over system font weight.", .japanese: "オンにすると、ウィジェット独自のフォント設定が優先されます。", .korean: "켜짐으로 설정하면 위젯의 사용자 지정 서체가 시스템 서체 굵기보다 우선 적용됩니다."],
        "desktop_and_indicators": [.simplifiedChinese: "桌面布局与指示器", .traditionalChinese: "桌面佈局與指示器", .english: "Desktop & Indicators", .japanese: "ホーム画面とインジケータ", .korean: "홈 화면 및 인디케이터"],
        "hide_home_indicator": [.simplifiedChinese: "隐藏底部指示条", .traditionalChinese: "隱藏底部指示條", .english: "Hide Home Bar", .japanese: "ホームバーを非表示", .korean: "홈 바 가리기"],
        "hide_status_bar": [.simplifiedChinese: "隐藏顶部状态栏", .traditionalChinese: "隱藏頂部狀態列", .english: "Hide Status Bar", .japanese: "ステータスバーを非表示", .korean: "상태 바 가리기"],
        "lock_screen": [.simplifiedChinese: "锁定屏幕", .traditionalChinese: "鎖定畫面", .english: "Lock Screen", .japanese: "ロック画面", .korean: "잠금 화면"],
        "home_screen": [.simplifiedChinese: "主屏幕", .traditionalChinese: "主畫面", .english: "Home Screen", .japanese: "ホーム画面", .korean: "홈 화면"],
        "customize": [.simplifiedChinese: "自定义", .traditionalChinese: "自訂", .english: "Customize", .japanese: "カスタマイズ", .korean: "사용자화"],
        "under_development": [.simplifiedChinese: "待开发", .traditionalChinese: "待開發", .english: "Coming Soon", .japanese: "開発中", .korean: "개발 중"]
    ]
    
    // 智能双向反查：用户无论是输入了中文、英文，直接反查并返回当前语言的目标值
    func findTranslation(for text: String, targetLang: AppLanguage) -> String? {
        let cleanText = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanText.isEmpty else { return nil }
        
        for (_, langMap) in dict {
            if langMap.values.contains(where: { $0.caseInsensitiveCompare(cleanText) == .orderedSame }) {
                if let target = langMap[targetLang], !target.isEmpty {
                    return target
                }
            }
        }
        return nil
    }
    
    func tr(_ key: String) -> String {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        if let match = dict[trimmed]?[currentLanguage] { return match }
        if let reverseMatch = findTranslation(for: trimmed, targetLang: currentLanguage) { return reverseMatch }
        return AutoTranslationManager.shared.translate(trimmed, to: currentLanguage)
    }
}

extension String {
    var tr: String { LanguageManager.shared.tr(self) }
}

// MARK: - 实时在线翻译引擎 (高吞吐防抖 + 纯内存 0 延迟管道)
class AutoTranslationManager: ObservableObject {
    static let shared = AutoTranslationManager()
    
    private let cacheKey = "App_Auto_Translation_Live_Store_V9"
    @Published var translationCache: [String: [String: String]] = [:]
    
    private var inFlightRequests = Set<String>()
    private var debounceTask: Task<Void, Never>?
    private let queue = DispatchQueue(label: "com.translation.queue", qos: .utility)
    
    init() {
        if let data = UserDefaults.standard.data(forKey: cacheKey),
           let decoded = try? JSONDecoder().decode([String: [String: String]].self, from: data) {
            self.translationCache = decoded
        }
    }
    
    private func saveCache() {
        if let data = try? JSONEncoder().encode(translationCache) {
            UserDefaults.standard.set(data, forKey: cacheKey)
        }
    }
    
    func prewarm(text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        debounceTask?.cancel()
        debounceTask = Task {
            try? await Task.sleep(nanoseconds: 400_000_000)
            guard !Task.isCancelled else { return }
            
            for lang in AppLanguage.allCases where lang != .simplifiedChinese {
                _ = await translateAsync(trimmed, to: lang)
            }
        }
    }
    
    func translate(_ text: String, to targetLang: AppLanguage? = nil) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return text }
        
        let lang = targetLang ?? LanguageManager.shared.currentLanguage
        if lang == .simplifiedChinese { return text }
        
        // 1. 本地静态字典直出 (直接匹配 Key)
        if let keyMatch = LanguageManager.shared.dict[trimmed]?[lang] { return keyMatch }
        
        // 1.5 智能双向反查 (用户输入“微信”或“WeChat”瞬间命中，0延迟秒出)
        if let reverseMatch = LanguageManager.shared.findTranslation(for: trimmed, targetLang: lang) {
            return reverseMatch
        }
        
        // 2. 繁体中文无损转换
        if lang == .traditionalChinese {
            let str = trimmed as NSString
            if let converted = str.applyingTransform(StringTransform("Hans-Hant"), reverse: false) {
                return converted
            }
        }
        
        // 3. 内存缓存直出（0 延迟）
        if let cached = translationCache[trimmed]?[lang.rawValue], !cached.isEmpty {
            return cached
        }
        
        // 4. 后台静默抓取
        let reqKey = "\(trimmed)_\(lang.rawValue)"
        if !inFlightRequests.contains(reqKey) {
            inFlightRequests.insert(reqKey)
            Task.detached(priority: .utility) {
                _ = await self.translateAsync(trimmed, to: lang)
            }
        }
        
        return text
    }
    
    func translateAsync(_ text: String, to targetLang: AppLanguage? = nil) async -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return text }
        
        let lang = targetLang ?? LanguageManager.shared.currentLanguage
        if lang == .simplifiedChinese { return text }
        
        if let cached = translationCache[trimmed]?[lang.rawValue], !cached.isEmpty { return cached }
        if let keyMatch = LanguageManager.shared.dict[trimmed]?[lang] { return keyMatch }
        if let reverseMatch = LanguageManager.shared.findTranslation(for: trimmed, targetLang: lang) { return reverseMatch }
        
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "+&=?")
        guard let encoded = trimmed.addingPercentEncoding(withAllowedCharacters: allowed) else {
            return text
        }
        
        let targetCode = lang.apiTargetCode
        if let url = URL(string: "https://translate.googleapis.com/translate_a/single?client=gtx&sl=zh-CN&tl=\(targetCode)&dt=t&q=\(encoded)") {
            var req = URLRequest(url: url)
            req.timeoutInterval = 2.5
            if let (data, _) = try? await URLSession.shared.data(for: req),
               let json = try? JSONSerialization.jsonObject(with: data) as? [Any],
               let firstArr = json.first as? [Any] {
                var clean = ""
                for item in firstArr {
                    if let part = item as? [Any], let piece = part.first as? String {
                        clean += piece
                    }
                }
                let finalResult = clean
                if !finalResult.isEmpty && finalResult != text {
                    await MainActor.run { () -> Void in
                        var existing = self.translationCache[trimmed] ?? [:]
                        existing[lang.rawValue] = finalResult
                        self.translationCache[trimmed] = existing
                        self.saveCache()
                        self.inFlightRequests.remove("\(trimmed)_\(lang.rawValue)")
                        self.objectWillChange.send()
                    }
                    return finalResult
                }
            }
        }
        
        await MainActor.run { () -> Void in
            self.inFlightRequests.remove("\(trimmed)_\(lang.rawValue)")
        }
        return text
    }
}

// MARK: - 纸飞机图标
struct InsSendPlaneIcon: View {
    var size: CGFloat = 16
    var color: Color = .secondary
    
    private static let iconData: Data? = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAC4AAAAwCAYAAABuZUjcAAAFiklEQVRoBdXBD4wVdAEA4O937+7dHRxyi/g3EoeKh7EWaLbJaNlVC0NARJJAtDccToqVEgVN+eMQB8rkJmYaaUY4lU3FhJ1cLBhOKjAaDqIOWrEolBF33cN378G7F9tjuzvv7t07HyB8X3CJCi5RwcVpJK7DEBzBThzURnBxGYp5qEYEl8k6gSfxrLOCi8NITMZ8pBBHGYpRhATSmIs3nBF8csoxCrdjIvogigwiOIz30RfXIGAj7kUi+GRMxd0YggHojUaUIoUNeAENmI45KMMhjENjcOH0wgTMwbWIoy8CUkihFmuwV6sYlqAU7+EO/Dc4/wbgBnwfo/Ehogg4jaOow6+xT3vF+Ckmogi/xSwkgvNnBKbgS7gGpShDC5I4hPV4G4eQ1NGV2IiBOIVnsdQZwbk3GhNQjStRhAqcQF/UYw1+h3/JbSJ+iQia8C2844zg3BmM+zEdUaSRRhT/QxyrsE7+1uB2RHAMn3VWULivYhy+gqFoQRolaMY2vIVNaNAzW1GFctTgYWcFH08FqjEOY3A50kijBcexC2+gFkk99xn8HgEluAu1zgp6rhqPYSCKUYKUrHJswhLUK8wCzEU5juMLaHRWkJ8KTMJ4jJUVQW/EcQy1eB27kda9alSiDk06egfD0AtbMFUbQW7XYySmYAzSKEEEp/AuduAt7JafUizCFPTHK7hPe8PxJj6NBBbjF9oIOleK1bgOgxGVVYIEjuIFbMD7yMhPP/wcn0MFIvgbbsJprW7DSlyGI7gT+7QRtDcIP8B4DEIKGVSiCYfxNF5GQs9cjzW4GqdRjCbMQa325mE+otiOGBq0EbS6AlsQRW80owIN2IldWIfjeibgVizE1cgggT+jBnXai2I9vo5mvIgFSGkjaHULXkKjrN44ibX4Gf6j5yoxH7ein6wivI4a7NPRl/EM+iGFlajxEUGrYXgZV6FZVhSH8RpWISG3gIysK7AAX0MlUojgRSxCXOdm4REkkcDd+IOPCDpajAkYhhakUYa/Ygl2IC634ViOsWhBCkk8jrVyexLTZP0R43Ui6KgCQ3EPvoFPoQUZNOMRPK9zAZNxP0YgjQj24DHU6d52XIuAZ/CgTgS5VeM7uBlFaMZGzNFRFHMxEwORRgTb8TD2694A7EYUH+Je1OlEkJ/vIYYy/AQbdbQa0xBBGeL4De5DWn7mYRGaEFCFuE4E+euDDE4io1UVavB5FCONY1iLp3BafiqxA5cjgT9hvC4EXQvIyG04luNGRGT9A8uwGRn5G4WtSKAc38YWXQgKE8OjKMNJ7MRC1Ou52ViGFjRgNBK6EBQmhlVI4Chm410fTw2my9qOO5DWhaAwMSxHC45gBur1XF9sRBUCnsZSOQSFiWEl4vgAU3FYz92C1YgiiYfwkhyCwsSwAlEcxp3Yq71SJOW2GN9FGodwDw7IIShMDMtQjv2Yiz2yBuPHmIy/4FW8ggbtRbEaU1GEzZipG0FhYliBZhzFNPwdAQ/gAZQjgibswgZsQqOs/liHUSjCcqzWjaAwMaxAMQ5iBuoxCU8hIIoipHEKKbyH5/EaqrANETRjFup0IyhMDKuQwj8xAwm8iSFII45/o0qrCFJ4G434JspxAmPwgW4EhYnhUZTgIJZjJqqRwmksxGbMxg34IiqQQDEySKMUOzFeHoLCxPAEmnEMe3ETIijBc3gQSVmDMRYLcBVSiCCOgLuwTR6CwsTwBBKIIqAJvbAHM3BMR4MwGzEUoRL7caM8BYWJYYWsgCT6oB4LUSe3SjyHUmxBjTwFhYnhcaSRQgrl+CHW61opklr1RaMeCAoTwwoERJDGr/AjpJ1HQWFiWIpyJHAAtyHuPAsKMwkr0R8H8BC2ugCCwvTHTIxALV51gQTnRimSLqDgEvV/Npx9QE7LYCgAAAAASUVORK5CYII=")
    
    private var uiImage: UIImage? {
        guard let data = Self.iconData, let image = UIImage(data: data) else { return nil }
        return image.withRenderingMode(.alwaysTemplate)
    }
    
    var body: some View {
        if let img = uiImage {
            Image(uiImage: img)
                .renderingMode(.template)
                .resizable()
                .scaledToFit()
                .foregroundColor(color)
                .frame(width: size, height: size)
        }
    }
}

// MARK: - 流式标签排版组件
struct FlowLayout: Layout {
    var spacing: CGFloat = 8
    
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let width = proposal.width ?? 0
        var height: CGFloat = 0
        var currentX: CGFloat = 0
        var currentY: CGFloat = 0
        var maxHeightInRow: CGFloat = 0
        
        for view in subviews {
            let size = view.sizeThatFits(.unspecified)
            if currentX + size.width > width && currentX > 0 {
                currentX = 0
                currentY += maxHeightInRow + spacing
                maxHeightInRow = 0
            }
            maxHeightInRow = max(maxHeightInRow, size.height)
            currentX += size.width + spacing
        }
        height = currentY + maxHeightInRow
        return CGSize(width: width, height: height)
    }
    
    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var currentX: CGFloat = bounds.minX
        var currentY: CGFloat = bounds.minY
        var maxHeightInRow: CGFloat = 0
        
        for view in subviews {
            let size = view.sizeThatFits(.unspecified)
            if currentX + size.width > bounds.maxX && currentX > bounds.minX {
                currentX = bounds.minX
                currentY += maxHeightInRow + spacing
                maxHeightInRow = 0
            }
            view.place(at: CGPoint(x: currentX, y: currentY), proposal: ProposedViewSize(size))
            maxHeightInRow = max(maxHeightInRow, size.height)
            currentX += size.width + spacing
        }
    }
}

extension Font {
    static var size64: Font { .system(size: 64) }
}
