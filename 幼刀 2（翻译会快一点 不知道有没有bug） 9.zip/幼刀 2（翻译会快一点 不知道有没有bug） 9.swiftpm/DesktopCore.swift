// MARK: - 3. DesktopCore (桌面核心数据算法与拖拽调度 · 极速流畅版)
import SwiftUI
import UIKit

@MainActor
final class DragCoordinator: ObservableObject {
    @Published var activeDraggingItem: AppItem? = nil
    @Published var activeGlobalLocation: CGPoint = .zero
    @Published var startGlobalLocation: CGPoint = .zero
    @Published var activeDragSource: AppLocation? = nil
    
    func start(item: AppItem, source: AppLocation, location: CGPoint) {
        activeDraggingItem = item
        activeDragSource = source
        activeGlobalLocation = location
        startGlobalLocation = location
    }
    
    func update(location: CGPoint) {
        activeGlobalLocation = location
    }
    
    func reset() {
        activeDraggingItem = nil
        activeDragSource = nil
        activeGlobalLocation = .zero
        startGlobalLocation = .zero
    }
}

@MainActor
class HomeScreenViewModel: ObservableObject {
    @Published var apps: [AppItem?] = []
    @Published var dockApps: [AppItem] = []
    @Published var isEditing: Bool = false
    
    let pageSize: Int = 24
    private let gridKey = "App_HomeScreen_Grid24_Data_Clean"
    private let dockKey = "App_HomeScreen_Dock4_Data_Clean"
    
    init() { 
        loadData() 
        resolveWidgetRowCollisions()
        evictAppsUnderWidgets()
    }
    
    func resolveWidgetRowCollisions() {
        let ins = InsPostWidgetManager.shared
        let korean = KoreanMessageWidgetManager.shared
        let photo = PhotoWidgetManager.shared
        let bubble = ChatBubbleWidgetManager.shared
        
        var activeWidgets: [any DesktopWidgetManager] = []
        if ins.isAddedToDesktop { activeWidgets.append(ins) }
        if photo.isAddedToDesktop { activeWidgets.append(photo) }
        if korean.isAddedToDesktop { activeWidgets.append(korean) }
        if bubble.isAddedToDesktop { activeWidgets.append(bubble) }
        
        let maxPage = activeWidgets.map { $0.widgetPage }.max() ?? 0
        for page in 0...max(maxPage + 1, 5) {
            let pageWidgets = activeWidgets.filter { $0.widgetPage == page }
            var occupied = Set<Int>()
            
            for w in pageWidgets {
                let needed = (w.sizeRows >= 4) ? [w.widgetRow, w.widgetRow + 2] : [w.widgetRow]
                let hasCollision = needed.contains { occupied.contains($0) }
                
                if hasCollision {
                    var freeCandidate: Int? = nil
                    for candidate in [0, 2, 4] {
                        let candNeeded = (w.sizeRows >= 4) ? [candidate, candidate + 2] : [candidate]
                        if !candNeeded.contains(where: { occupied.contains($0) }) {
                            freeCandidate = candidate
                            break
                        }
                    }
                    
                    if let free = freeCandidate {
                        w.widgetRow = free
                        occupied.insert(free)
                        if w.sizeRows >= 4 { occupied.insert(free + 2) }
                    } else {
                        w.widgetPage = page + 1
                        w.widgetRow = 0
                    }
                } else {
                    for r in needed { occupied.insert(r) }
                }
            }
        }
    }
    
    func findAvailablePlacement(forRows neededRows: Int = 2) -> (page: Int, row: Int) {
        for page in 0...10 {
            var occupied = Set<Int>()
            let ins = InsPostWidgetManager.shared
            let korean = KoreanMessageWidgetManager.shared
            let photo = PhotoWidgetManager.shared
            let bubble = ChatBubbleWidgetManager.shared
            
            let allW: [(isAdded: Bool, page: Int, row: Int, rows: Int)] = [
                (ins.isAddedToDesktop, ins.widgetPage, ins.widgetRow, 4),
                (photo.isAddedToDesktop, photo.widgetPage, photo.widgetRow, 2),
                (korean.isAddedToDesktop, korean.widgetPage, korean.widgetRow, 2),
                (bubble.isAddedToDesktop, bubble.widgetPage, bubble.widgetRow, 2)
            ]
            
            for widget in allW where widget.isAdded && widget.page == page {
                occupied.insert(widget.row)
                if widget.rows >= 4 { occupied.insert(widget.row + 2) }
            }
            
            if neededRows >= 4 {
                if !occupied.contains(0) && !occupied.contains(2) { return (page, 0) }
                else if !occupied.contains(2) && !occupied.contains(4) { return (page, 2) }
            } else {
                for candidate in [0, 2, 4] {
                    if !occupied.contains(candidate) { return (page, candidate) }
                }
            }
        }
        return (0, 0)
    }
    
    func getCoveredIndices() -> Set<Int> {
        let ins = InsPostWidgetManager.shared
        let korean = KoreanMessageWidgetManager.shared
        let photo = PhotoWidgetManager.shared
        let bubble = ChatBubbleWidgetManager.shared
        
        var covered = Set<Int>()
        
        if ins.isAddedToDesktop {
            for r in 0..<4 {
                for c in 0..<4 {
                    covered.insert(ins.widgetPage * pageSize + (ins.widgetRow + r) * 4 + c)
                }
            }
        }
        if photo.isAddedToDesktop {
            for r in 0..<2 {
                for c in 0..<4 {
                    covered.insert(photo.widgetPage * pageSize + (photo.widgetRow + r) * 4 + c)
                }
            }
        }
        if korean.isAddedToDesktop {
            for r in 0..<2 {
                for c in 0..<4 {
                    covered.insert(korean.widgetPage * pageSize + (korean.widgetRow + r) * 4 + c)
                }
            }
        }
        if bubble.isAddedToDesktop {
            let startCol = bubble.widgetCol * 2
            for r in 0..<2 {
                for c in 0..<2 {
                    covered.insert(bubble.widgetPage * pageSize + (bubble.widgetRow + r) * 4 + (startCol + c))
                }
            }
        }
        return covered
    }
    
    func smartRelocateWidget(
        oldPage: Int, oldRow: Int, oldCol: Int,
        newPage: Int, newRow: Int, newCol: Int,
        sizeRows: Int, sizeCols: Int,
        updatePosition: () -> Void
    ) {
        var oldSlots: [Int] = []
        for r in 0..<sizeRows {
            for c in 0..<sizeCols {
                oldSlots.append(oldPage * pageSize + (oldRow + r) * 4 + (oldCol + c))
            }
        }
        
        updatePosition()
        resolveWidgetRowCollisions()
        
        let covered = getCoveredIndices()
        
        var targetSlots: [Int] = []
        for r in 0..<sizeRows {
            for c in 0..<sizeCols {
                targetSlots.append(newPage * pageSize + (newRow + r) * 4 + (newCol + c))
            }
        }
        
        var displacedApps: [AppItem] = []
        for slot in targetSlots {
            if slot < apps.count, let item = apps[slot] {
                displacedApps.append(item)
                apps[slot] = nil
            }
        }
        
        for slot in covered {
            if slot < apps.count, let item = apps[slot] {
                if !displacedApps.contains(where: { $0.id == item.id }) {
                    displacedApps.append(item)
                }
                apps[slot] = nil
            }
        }
        
        // 1. 优先互换到腾出的旧空位
        let availableOldSlots = oldSlots.filter { !covered.contains($0) }
        for slot in availableOldSlots {
            if displacedApps.isEmpty { break }
            while apps.count <= slot { apps.append(nil) }
            apps[slot] = displacedApps.removeFirst()
        }
        
        // 2. 剩余软件向后寻找空位，满了自动顺延到下一页
        var scanIdx = 0
        while !displacedApps.isEmpty {
            if scanIdx < apps.count {
                if !covered.contains(scanIdx) && apps[scanIdx] == nil {
                    apps[scanIdx] = displacedApps.removeFirst()
                }
                scanIdx += 1
            } else {
                if covered.contains(scanIdx) {
                    apps.append(nil)
                    scanIdx += 1
                } else {
                    apps.append(displacedApps.removeFirst())
                    scanIdx += 1
                }
            }
        }
        
        while apps.count < pageSize { apps.append(nil) }
        deduplicateApps()
        saveApps()
    }
    
    func evictAppsUnderWidgets(vacatedSlots: [Int] = []) {
        resolveWidgetRowCollisions()
        let covered = getCoveredIndices()
        
        var displacedApps: [AppItem] = []
        for i in 0..<apps.count {
            if covered.contains(i), let item = apps[i] {
                displacedApps.append(item)
                apps[i] = nil
            }
        }
        
        for app in displacedApps {
            var target = 0
            while true {
                if target < apps.count {
                    if !covered.contains(target) && apps[target] == nil {
                        apps[target] = app
                        break
                    }
                    target += 1
                } else {
                    if covered.contains(target) {
                        apps.append(nil)
                        target += 1
                    } else {
                        apps.append(app)
                        break
                    }
                }
            }
        }
        
        while apps.count < pageSize { apps.append(nil) }
        saveApps()
    }
    
    func loadData() {
        let isFirstEverLaunch = UserDefaults.standard.object(forKey: gridKey) == nil && UserDefaults.standard.object(forKey: dockKey) == nil
        var loadedApps: [AppItem?] = []
        if let data = UserDefaults.standard.data(forKey: gridKey),
           let decoded = try? JSONDecoder().decode([AppItem?].self, from: data) {
            loadedApps = decoded
        }
        while loadedApps.count < pageSize { loadedApps.append(nil) }
        var loadedDock: [AppItem] = []
        if let data = UserDefaults.standard.data(forKey: dockKey),
           let decoded = try? JSONDecoder().decode([AppItem].self, from: data) {
            loadedDock = Array(decoded.prefix(4))
        } else if isFirstEverLaunch {
            loadedDock = [AppItem(id: "wechat", title: "微信", icon: "message.fill", colorName: "green")]
        }
        
        self.apps = loadedApps
        self.dockApps = loadedDock
        let existingIds = Set(apps.compactMap { $0?.id } + dockApps.map { $0.id })
        
        let essentialApps: [AppItem] = [
            AppItem(id: "settings", title: "设置", icon: "gearshape.fill", colorName: "gray"),
            AppItem(id: "iscreen", title: "iScreen", icon: "square.grid.2x2.fill", colorName: "purple"),
            AppItem(id: "wechat", title: "微信", icon: "message.fill", colorName: "green")
        ]
        
        let covered = getCoveredIndices()
        for essential in essentialApps {
            if !existingIds.contains(essential.id) {
                var target = 0
                while true {
                    if target < self.apps.count {
                        if !covered.contains(target) && self.apps[target] == nil {
                            self.apps[target] = essential
                            break
                        }
                        target += 1
                    } else {
                        if covered.contains(target) {
                            self.apps.append(nil)
                            target += 1
                        } else {
                            self.apps.append(essential)
                            break
                        }
                    }
                }
            }
        }
        
        evictAppsUnderWidgets()
        deduplicateApps()
        saveApps()
    }
    
    func deduplicateApps() {
        var seenIds = Set<String>()
        var uniqueDock: [AppItem] = []
        for item in dockApps {
            if !seenIds.contains(item.id) { seenIds.insert(item.id); uniqueDock.append(item) }
        }
        self.dockApps = uniqueDock
        for (index, item) in apps.enumerated() {
            if let item = item {
                if seenIds.contains(item.id) { apps[index] = nil }
                else { seenIds.insert(item.id) }
            }
        }
    }
    
    func saveApps() {
        let currentApps = self.apps
        let currentDock = self.dockApps
        let gKey = self.gridKey
        let dKey = self.dockKey
        Task.detached(priority: .utility) {
            if let data = try? JSONEncoder().encode(currentApps) { UserDefaults.standard.set(data, forKey: gKey) }
            if let data = try? JSONEncoder().encode(currentDock) { UserDefaults.standard.set(data, forKey: dKey) }
        }
    }
    
    func moveItem(from source: AppLocation, to destination: AppLocation) {
        guard source != destination else { return }
        let covered = getCoveredIndices()
        
        switch (source, destination) {
        case (.grid(let from), .grid(let to)):
            guard from < apps.count else { return }
            var finalTo = to
            
            if covered.contains(finalTo) {
                let startSearch = (finalTo / pageSize) * pageSize
                if let free = (startSearch..<apps.count).first(where: { !covered.contains($0) && apps[$0] == nil }) {
                    finalTo = free
                } else if let free = (0..<apps.count).first(where: { !covered.contains($0) && apps[$0] == nil }) {
                    finalTo = free
                } else {
                    finalTo = apps.count
                    while covered.contains(finalTo) { finalTo += 1 }
                }
            }
            
            while apps.count <= finalTo { apps.append(nil) }
            let target = apps[finalTo]
            apps[finalTo] = apps[from]
            apps[from] = target
            
        case (.dock(let from), .dock(let to)):
            guard from < dockApps.count, to < dockApps.count, from != to else { return }
            let item = dockApps.remove(at: from)
            dockApps.insert(item, at: min(to, dockApps.count))
            
        case (.grid(let fromGrid), .dock(let toDock)):
            guard fromGrid < apps.count, let movingItem = apps[fromGrid] else { return }
            apps[fromGrid] = nil
            dockApps.removeAll(where: { $0.id == movingItem.id })
            if dockApps.count < 4 {
                dockApps.insert(movingItem, at: min(toDock, dockApps.count))
            } else {
                let safeIndex = min(toDock, dockApps.count - 1)
                let targetDockItem = dockApps[safeIndex]
                dockApps[safeIndex] = movingItem
                apps[fromGrid] = targetDockItem
            }
            
        case (.dock(let fromDock), .grid(let toGrid)):
            guard fromDock < dockApps.count else { return }
            var finalTo = toGrid
            if covered.contains(finalTo) {
                if let free = (0..<apps.count).first(where: { !covered.contains($0) && apps[$0] == nil }) {
                    finalTo = free
                } else {
                    finalTo = apps.count
                    while covered.contains(finalTo) { finalTo += 1 }
                }
            }
            while apps.count <= finalTo { apps.append(nil) }
            let movingItem = dockApps.remove(at: fromDock)
            if let targetExisting = apps[finalTo] {
                if !dockApps.contains(where: { $0.id == targetExisting.id }) && dockApps.count < 4 {
                    dockApps.insert(targetExisting, at: min(fromDock, dockApps.count))
                }
            }
            apps[finalTo] = movingItem
        }
        
        while apps.count < pageSize { apps.append(nil) }
        deduplicateApps()
        saveApps()
    }
    
    func totalPages() -> Int {
        var maxPage = 0
        let ins = InsPostWidgetManager.shared
        let korean = KoreanMessageWidgetManager.shared
        let photo = PhotoWidgetManager.shared
        let bubble = ChatBubbleWidgetManager.shared
        
        let allW = [ins.widgetPage, korean.widgetPage, photo.widgetPage, bubble.widgetPage]
        if let maxW = allW.max() { maxPage = max(maxPage, maxW) }
        
        if let lastIndex = apps.lastIndex(where: { $0 != nil }) {
            maxPage = max(maxPage, lastIndex / pageSize)
        }
        return max(1, maxPage + 1)
    }
    
    func slotsForPage(_ pageIndex: Int) -> [(index: Int, item: AppItem?)] {
        let start = pageIndex * pageSize
        let end = min(start + pageSize, apps.count)
        return (start..<end).map { (index: $0, item: apps[$0]) }
    }
}

// MARK: - 真实 iOS 细腻微晃动画引擎
struct JiggleModifier: ViewModifier {
    let isEditing: Bool
    let slotIndex: Int
    @State private var isWiggling = false
    
    private var angle: Double { slotIndex >= 666 ? 0.65 : 1.15 }
    
    func body(content: Content) -> some View {
        content
            .rotationEffect(.degrees(isEditing ? (isWiggling ? angle : -angle) : 0))
            .animation(
                isEditing
                ? Animation.easeInOut(duration: 0.13).repeatForever(autoreverses: true).delay(slotIndex.isMultiple(of: 2) ? 0.0 : 0.06)
                : .easeInOut(duration: 0.18),
                value: isWiggling
            )
            .onAppear { if isEditing { isWiggling = true } }
            .onChange(of: isEditing) { _, editing in isWiggling = editing }
    }
}

// MARK: - 基础图像与删除减号组件
struct NativeImage: View {
    var data: Data?
    var body: some View {
        if let data = data, let uiImage = UIImage(data: data) {
            Image(uiImage: uiImage).resizable().scaledToFill()
        } else {
            Color.black
        }
    }
}

struct WidgetDeleteBadge: View {
    var body: some View {
        ZStack {
            Circle().fill(.ultraThinMaterial).frame(width: 24, height: 24)
            Circle().fill(Color.black.opacity(0.45)).frame(width: 24, height: 24)
            Image(systemName: "minus").font(.system(size: 11, weight: .black)).foregroundColor(.white)
            Circle().stroke(Color.white.opacity(0.32), lineWidth: 0.8).frame(width: 24, height: 24)
        }
        .shadow(color: Color.black.opacity(0.2), radius: 6, x: 0, y: 3)
    }
}

// MARK: - App 图标通用组件
struct AppIcon: View {
    var icon: String
    var color: Color
    var title: String? = nil
    var textColor: Color = .white
    var customImageData: Data? = nil
    var action: () -> Void
    
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    var body: some View {
        VStack(spacing: 3) {
            Button(action: action) {
                Group {
                    if let data = customImageData, let uiImage = UIImage(data: data) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 60, height: 60)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .stroke(Color.white.opacity(0.18), lineWidth: 0.8)
                            )
                    } else {
                        Image(systemName: icon)
                            .font(.system(size: 35))
                            .foregroundColor(.white)
                            .frame(width: 60, height: 60)
                            .background(color)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                }
            }
            if let title = title {
                Text(translator.translate(title))
                    .font(.caption)
                    .fontWeight(appearance.systemFontWeight)
                    .foregroundColor(textColor)
            }
        }
    }
}
