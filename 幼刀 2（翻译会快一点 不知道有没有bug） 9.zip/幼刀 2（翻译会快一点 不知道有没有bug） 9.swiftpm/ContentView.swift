import SwiftUI

// MARK: - 全局根入口
struct ContentView: View {
    @State private var isUnlocked = false
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if isUnlocked {
                HomeScreenView(isUnlocked: $isUnlocked)
                    .transition(.opacity)
            } else {
                LockScreenView(isUnlocked: $isUnlocked)
                    .transition(.opacity)
            }
        }
    }
}

// MARK: - AI微信主视图
struct AIWeChatView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("聊天界面 (待开发)".tr)
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(.gray)
            }
            .navigationTitle(lang.tr("app_wechat"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                            show = false
                        }
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                    }
                }
            }
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15)
                .onEnded { value in
                    if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                        let generator = UIImpactFeedbackGenerator(style: .light)
                        generator.impactOccurred()
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) {
                            show = false
                        }
                    }
                }
        )
    }
}
